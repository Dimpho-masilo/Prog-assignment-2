/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.mavenproject2;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * JUnit 5 tests for the WildLife SA Rescue Operations System.
 *
 * Test data (used in setUp):
 *   Injured   : 5 days x R500 + vet R3,000 + surgery R5,000      = R10,500
 *   Orphaned  : 10 days x R300 + feeding R1,200 + foster R2,500  = R6,700
 *   Endangered: 4 days x R800 + security R2,000 (no team)        = R5,200
 */
class RescueSystemTest {

    private static final double DELTA = 0.001;

    private RescueManager manager;
    private InjuredAnimalRescue injured;
    private OrphanedAnimalRescue orphaned;
    private EndangeredSpeciesRescue endangered;

    @BeforeEach
    void setUp() {
        manager = new RescueManager();
        injured = new InjuredAnimalRescue("R001", "Simba", "Lion", "Kruger", "Thabo",
                5, 500.0, "Broken leg", 3000.0, true);
        orphaned = new OrphanedAnimalRescue("R002", "Tiny", "Rhino", "Limpopo", "Anna",
                10, 300.0, 2, 1200.0, true);
        endangered = new EndangeredSpeciesRescue("R003", "Rocky", "Black Rhino", "Pilanesberg", "Sipho",
                4, 800.0, "Critically Endangered", 2000.0, false);
    }

    // ---------------------------------------------------------------- cost calculation

    @Test
    @DisplayName("Injured: total = days x daily + vet cost + R5,000 surgery fee")
    void injuredCostWithSurgery() {
        assertEquals(10500.0, injured.calculateTotalCost(), DELTA);
    }

    @Test
    @DisplayName("Injured: no surgery fee when surgery is not required")
    void injuredCostWithoutSurgery() {
        InjuredAnimalRescue c = new InjuredAnimalRescue("R010", "Zola", "Zebra", "Kruger", "Thabo",
                5, 500.0, "Cut", 3000.0, false);
        assertEquals(5500.0, c.calculateTotalCost(), DELTA);
    }

    @Test
    @DisplayName("Orphaned: total includes feeding cost and R2,500 foster care fee")
    void orphanedCostWithFoster() {
        assertEquals(6700.0, orphaned.calculateTotalCost(), DELTA);
    }

    @Test
    @DisplayName("Orphaned: no foster fee when foster care is not required")
    void orphanedCostWithoutFoster() {
        OrphanedAnimalRescue c = new OrphanedAnimalRescue("R011", "Bo", "Elephant", "Addo", "Anna",
                10, 300.0, 6, 1200.0, false);
        assertEquals(4200.0, c.calculateTotalCost(), DELTA);
    }

    @Test
    @DisplayName("Endangered: total includes security cost; specialist team adds R8,000")
    void endangeredCost() {
        assertEquals(5200.0, endangered.calculateTotalCost(), DELTA);
        EndangeredSpeciesRescue withTeam = new EndangeredSpeciesRescue("R012", "Ace", "Pangolin", "Kruger",
                "Sipho", 4, 800.0, "Endangered", 2000.0, true);
        assertEquals(13200.0, withTeam.calculateTotalCost(), DELTA);
    }

    // ---------------------------------------------------------------- priority

    @Test
    @DisplayName("Injured priority: surgery=CRITICAL, vet>=R10,000=HIGH, otherwise MEDIUM")
    void injuredPriority() {
        assertEquals(RescuePriority.CRITICAL, injured.determinePriority());

        InjuredAnimalRescue expensive = new InjuredAnimalRescue("R020", "A", "Buffalo", "Kruger", "Thabo",
                2, 100.0, "Deep wound", 10000.0, false);
        assertEquals(RescuePriority.HIGH, expensive.determinePriority());

        InjuredAnimalRescue minor = new InjuredAnimalRescue("R021", "B", "Buffalo", "Kruger", "Thabo",
                2, 100.0, "Scratch", 500.0, false);
        assertEquals(RescuePriority.MEDIUM, minor.determinePriority());
    }

    @Test
    @DisplayName("Orphaned priority: <=3 months HIGH, <=12 MEDIUM, older LOW (boundary values)")
    void orphanedPriority() {
        assertEquals(RescuePriority.HIGH, orphaned.determinePriority());          // 2 months
        assertEquals(RescuePriority.HIGH, orphanedOfAge("R030", 3).determinePriority());
        assertEquals(RescuePriority.MEDIUM, orphanedOfAge("R031", 4).determinePriority());
        assertEquals(RescuePriority.MEDIUM, orphanedOfAge("R032", 12).determinePriority());
        assertEquals(RescuePriority.LOW, orphanedOfAge("R033", 13).determinePriority());
    }

    @Test
    @DisplayName("Endangered priority: Critically Endangered or specialist team=CRITICAL, else HIGH")
    void endangeredPriority() {
        assertEquals(RescuePriority.CRITICAL, endangered.determinePriority());

        EndangeredSpeciesRescue plain = new EndangeredSpeciesRescue("R040", "C", "Cheetah", "Kruger",
                "Sipho", 3, 400.0, "Endangered", 1000.0, false);
        assertEquals(RescuePriority.HIGH, plain.determinePriority());

        EndangeredSpeciesRescue withTeam = new EndangeredSpeciesRescue("R041", "D", "Cheetah", "Kruger",
                "Sipho", 3, 400.0, "Endangered", 1000.0, true);
        assertEquals(RescuePriority.CRITICAL, withTeam.determinePriority());
    }

    // ---------------------------------------------------------------- rescue operations

    @Test
    @DisplayName("A new case starts as REPORTED")
    void newCaseIsReported() {
        assertEquals(RescueStatus.REPORTED, injured.getStatus());
    }

    @Test
    @DisplayName("startRescue moves REPORTED -> IN_PROGRESS, completeRescue moves it to COMPLETED")
    void rescueLifecycle() {
        injured.startRescue();
        assertEquals(RescueStatus.IN_PROGRESS, injured.getStatus());
        injured.completeRescue();
        assertEquals(RescueStatus.COMPLETED, injured.getStatus());
    }

    @Test
    @DisplayName("Cannot complete a rescue that has not started")
    void cannotCompleteBeforeStart() {
        assertThrows(IllegalStateException.class, () -> injured.completeRescue());
        assertEquals(RescueStatus.REPORTED, injured.getStatus());
    }

    @Test
    @DisplayName("Cannot start a rescue twice, or start one that is already completed")
    void cannotStartTwice() {
        injured.startRescue();
        assertThrows(IllegalStateException.class, () -> injured.startRescue());
        injured.completeRescue();
        assertThrows(IllegalStateException.class, () -> injured.startRescue());
        assertThrows(IllegalStateException.class, () -> injured.completeRescue());
    }

    @Test
    @DisplayName("Summary contains all required fields")
    void summaryContainsRequiredFields() {
        injured.startRescue();
        String summary = injured.generateSummary();
        assertTrue(summary.contains("R001"));
        assertTrue(summary.contains("Injured Animal"));
        assertTrue(summary.contains("Lion"));
        assertTrue(summary.contains("Thabo"));
        assertTrue(summary.contains("CRITICAL"));
        assertTrue(summary.contains("In Progress"));
        assertTrue(summary.contains("R10,500.00"));
    }

    @Test
    @DisplayName("Type-specific details are displayed")
    void specificDetails() {
        assertTrue(injured.getSpecificDetails().contains("Broken leg"));
        assertTrue(orphaned.getSpecificDetails().contains("2 months"));
        assertTrue(endangered.getSpecificDetails().contains("Critically Endangered"));
    }

    // ---------------------------------------------------------------- validation

    @Test
    @DisplayName("Invalid data is rejected")
    void validation() {
        assertThrows(IllegalArgumentException.class, () ->
                new InjuredAnimalRescue(" ", "X", "Lion", "Kruger", "Thabo", 1, 100.0, "Leg", 100.0, false));
        assertThrows(IllegalArgumentException.class, () ->
                new InjuredAnimalRescue("R050", "X", null, "Kruger", "Thabo", 1, 100.0, "Leg", 100.0, false));
        assertThrows(IllegalArgumentException.class, () ->
                new InjuredAnimalRescue("R051", "X", "Lion", "Kruger", "Thabo", 0, 100.0, "Leg", 100.0, false));
        assertThrows(IllegalArgumentException.class, () ->
                new InjuredAnimalRescue("R052", "X", "Lion", "Kruger", "Thabo", 1, -5.0, "Leg", 100.0, false));
        assertThrows(IllegalArgumentException.class, () ->
                new OrphanedAnimalRescue("R053", "X", "Lion", "Kruger", "Thabo", 1, 100.0, 0, 100.0, false));
        assertThrows(IllegalArgumentException.class, () ->
                new EndangeredSpeciesRescue("R054", "X", "Lion", "Kruger", "Thabo", 1, 100.0, "", 100.0, false));
    }

    @Test
    @DisplayName("A blank animal name becomes 'Unnamed'")
    void blankAnimalNameDefaults() {
        InjuredAnimalRescue c = new InjuredAnimalRescue("R060", "  ", "Lion", "Kruger", "Thabo",
                1, 100.0, "Leg", 100.0, false);
        assertEquals("Unnamed", c.getAnimalName());
    }

    // ---------------------------------------------------------------- RescueManager

    @Test
    @DisplayName("Cases can be added and counted")
    void addCases() {
        assertEquals(0, manager.getCaseCount());
        manager.addCase(injured);
        manager.addCase(orphaned);
        assertEquals(2, manager.getCaseCount());
    }

    @Test
    @DisplayName("Duplicate Rescue Case IDs are rejected (case-insensitive)")
    void duplicateIdRejected() {
        manager.addCase(injured);
        InjuredAnimalRescue duplicate = new InjuredAnimalRescue("r001", "Other", "Lion", "Kruger", "Thabo",
                1, 100.0, "Leg", 100.0, false);
        assertThrows(IllegalArgumentException.class, () -> manager.addCase(duplicate));
        assertEquals(1, manager.getCaseCount());
    }

    @Test
    @DisplayName("Null case is rejected")
    void nullCaseRejected() {
        assertThrows(IllegalArgumentException.class, () -> manager.addCase(null));
    }

    @Test
    @DisplayName("findById returns the case, ignoring case and spaces, or null when missing")
    void findById() {
        manager.addCase(injured);
        assertSame(injured, manager.findById("R001"));
        assertSame(injured, manager.findById("  r001 "));
        assertNull(manager.findById("R999"));
        assertNull(manager.findById(null));
    }

    @Test
    @DisplayName("updateStatus changes an existing case and returns false for an unknown ID")
    void updateStatus() {
        manager.addCase(injured);
        assertTrue(manager.updateStatus("R001", RescueStatus.COMPLETED));
        assertEquals(RescueStatus.COMPLETED, injured.getStatus());
        assertFalse(manager.updateStatus("R999", RescueStatus.COMPLETED));
    }

    @Test
    @DisplayName("Total estimated cost sums every case polymorphically")
    void totalEstimatedCost() {
        manager.addCase(injured);
        manager.addCase(orphaned);
        manager.addCase(endangered);
        assertEquals(22400.0, manager.getTotalEstimatedCost(), DELTA);
    }

    @Test
    @DisplayName("Different rescue types work through the RescueCase reference (polymorphism)")
    void polymorphism() {
        List<RescueCase> all = List.of(injured, orphaned, endangered);
        assertEquals("Injured Animal", all.get(0).getRescueType());
        assertEquals("Orphaned Animal", all.get(1).getRescueType());
        assertEquals("Endangered Species", all.get(2).getRescueType());
    }

    @Test
    @DisplayName("The list returned by getAllCases cannot be modified from outside")
    void allCasesIsReadOnly() {
        manager.addCase(injured);
        List<RescueCase> view = manager.getAllCases();
        assertThrows(UnsupportedOperationException.class, () -> view.add(orphaned));
    }

    // ---------------------------------------------------------------- report

    @Test
    @DisplayName("Report lists every case and ends with the totals")
    void report() {
        manager.addCase(injured);
        manager.addCase(orphaned);
        manager.addCase(endangered);
        String report = manager.generateReport();
        assertTrue(report.contains("R001"));
        assertTrue(report.contains("R002"));
        assertTrue(report.contains("R003"));
        assertTrue(report.contains("Total Rescue Cases"));
        assertTrue(report.contains(": 3"));
        assertTrue(report.contains("R22,400.00"));
    }

    @Test
    @DisplayName("Report for an empty system says no cases are recorded")
    void emptyReport() {
        assertTrue(manager.generateReport().contains("No rescue cases recorded."));
    }

    @Test
    @DisplayName("Money is formatted as Rand with thousands separator and 2 decimals")
    void formatMoney() {
        assertEquals("R1,234.50", RescueCase.formatMoney(1234.5));
        assertEquals("R0.00", RescueCase.formatMoney(0));
    }

    // ---------------------------------------------------------------- helper

    private OrphanedAnimalRescue orphanedOfAge(String id, int months) {
        return new OrphanedAnimalRescue(id, "Baby", "Elephant", "Addo", "Anna",
                1, 100.0, months, 100.0, false);
    }
}